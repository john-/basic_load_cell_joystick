#include <Arduino.h>
#include <Wire.h>
#include <EEPROM.h>
#include <Joystick.h>
#include <stdlib.h>
#include <vector>

uint64_t sim_us = 0; volatile uint8_t TWBR = 0;
std::string serial_out, serial_in; SerialStub Serial;
uint8_t sim_eeprom[1024]; EEPROMStub EEPROM;
FakeAds sim_ads[2]; int sim_nack_next = 0; bool sim_dead[2] = {false, false}; TwoWire Wire;
uint32_t millis() { return (uint32_t)(sim_us / 1000); }
uint32_t micros() { return (uint32_t)sim_us; }
void delay(unsigned long ms) { sim_us += ms * 1000; }
void delayMicroseconds(unsigned int us) { sim_us += us; }
static int pinval[32]; static int ledWrites = 0;
void pinMode(uint8_t, uint8_t) {}
void digitalWrite(uint8_t p, uint8_t v) { pinval[p] = v; }
int digitalRead(uint8_t p) {
  if (p == 16) return sim_ads[0].drdyLow() ? LOW : HIGH;
  if (p == 10) return sim_ads[1].drdyLow() ? LOW : HIGH;
  return pinval[p];
}

static float g_load[4]; static long g_off[4] = {120000, -80000, 40000, 0}; static bool g_noise = true; static uint32_t rng = 1;
int32_t sim_input(uint8_t a, uint8_t mux) {
  int c = -1; if (a == 0x40 && mux == 0) c = 0; if (a == 0x40 && mux == 6) c = 1; if (a == 0x41 && mux == 0) c = 2;
  if (c < 0) return 0;
  rng = rng * 1664525u + 1013904223u;
  long n = g_noise ? (long)((rng >> 24) % 7) - 3 : 0;
  return (int32_t)(g_off[c] + (long)(g_load[c] * 107374.0f) + n);
}

#include "load_cell_joystick.ino"

static int fails = 0, checks = 0;
#define CHECK(c, ...) do { checks++; if (!(c)) { fails++; printf("  FAIL line %d: ", __LINE__); printf(__VA_ARGS__); printf("\n"); } } while (0)
static void run_ms(int ms) { uint64_t end = sim_us + (uint64_t)ms * 1000; while (sim_us < end) { sim_us += 25; loop(); } }
static void keys(const char *s) { serial_in += s; }
static bool has(const char *s) { return serial_out.find(s) != std::string::npos; }
static void loads(float p, float r, float z) {   // pure Pitch (dir 90deg), Roll (dir 0deg), Z loads in kg per cell
  const float ang[3] = {0, 120, 240};
  for (int i = 0; i < 3; i++) g_load[i] = p * sinf(ang[i] * 3.14159265f / 180) + r * cosf(ang[i] * 3.14159265f / 180) + z;
}
static void saveEE(const char *f) { FILE *fp = fopen(f, "wb"); fwrite(sim_eeprom, 1, 1024, fp); fclose(fp); }
static void initSim() {
  sim_ads[0].addr = 0x40; sim_ads[1].addr = 0x41;
  memset(sim_eeprom, 0xFF, sizeof sim_eeprom);
  for (int i = 0; i < 32; i++) pinval[i] = HIGH;
}

int main(int argc, char **argv) {
  initSim();
  bool reboot = argc > 1 && !strcmp(argv[1], "reboot");
  if (reboot) { FILE *fp = fopen("ee.bin", "rb"); fread(sim_eeprom, 1, 1024, fp); fclose(fp); }
  setup();
  run_ms(1500);
  CHECK(g_state == ST_RUN, "boot -> RUN, state=%d", g_state);
  CHECK(TWBR == 10, "TWBR=%d", TWBR);
  CHECK(sim_ads[0].cfgErr == 0 && sim_ads[1].cfgErr == 0, "ADC config bits wrong (%d/%d)", sim_ads[0].cfgErr, sim_ads[1].cfgErr);
  CHECK(g_fps >= 100, "frame rate %d Hz", g_fps);
  printf("frame rate: %d Hz, I2C starts chip0=%d chip1=%d\n", g_fps, sim_ads[0].starts, sim_ads[1].starts);
  CHECK(sim_ads[1].starts * 2 <= sim_ads[0].starts + 4 && sim_ads[1].starts > 50, "chip1 should start once per frame, chip0 twice (%d vs %d)", sim_ads[1].starts, sim_ads[0].starts);
  CHECK(Joystick.y == 0 && Joystick.x == 0 && Joystick.z == 0, "rest axes %d %d %d", Joystick.x, Joystick.y, Joystick.z);
  CHECK(fabsf(g_tare[0] - 120000) < 5 && fabsf(g_tare[1] + 80000) < 5, "tare %.1f %.1f %.1f", g_tare[0], g_tare[1], g_tare[2]);

  if (reboot) {
    CHECK(g_loadResult == LOAD_OK, "EEPROM should load after calibration");
    CHECK(fabsf(g_cal.axisScale[AX_PITCH] - 128849) < 3000, "persisted pitch scale %.0f", g_cal.axisScale[0]);
    CHECK(!has("EEPROM invalid"), "no invalid warning on reboot");
    printf("reboot: %d checks, %d failures\n", checks, fails); return fails != 0;
  }
  CHECK(has("EEPROM invalid"), "blank EEPROM must warn, not fault");

  // ---- axis math & signs (defaults: scale 144000/144000/54000, dz 1200/1200/2100) ----
  loads(0.8f, 0, 0); run_ms(300);
  float expP = 1.5f * 0.8f * 107374.0f;
  CHECK(fabsf(g_v[AX_PITCH] - expP) < 800 && fabsf(g_v[AX_ROLL]) < 800 && fabsf(g_v[AX_Z]) < 800, "pure pitch decouples: P=%.0f R=%.0f Z=%.0f (exp P %.0f)", g_v[0], g_v[1], g_v[2], expP);
  int expY = -(int)((expP - 1200) / (144000 - 1200) * 32767 + 0.5f);
  CHECK(abs(Joystick.y - expY) < 60 && Joystick.x == 0 && Joystick.z == 0, "forward push -> negative Y: y=%d exp %d x=%d z=%d", Joystick.y, expY, Joystick.x, Joystick.z);
  loads(0, 0.8f, 0); run_ms(300);
  CHECK(Joystick.x > 25000 && Joystick.y == 0 && Joystick.z == 0, "roll: x=%d y=%d z=%d", Joystick.x, Joystick.y, Joystick.z);
  loads(0, 0, 0.5f / 3); run_ms(300);
  CHECK(Joystick.z > 30000 && Joystick.x == 0 && Joystick.y == 0, "z: z=%d x=%d y=%d", Joystick.z, Joystick.x, Joystick.y);
  loads(0.005f, 0, 0); run_ms(200);
  CHECK(Joystick.y == 0, "inside deadzone -> 0, y=%d", Joystick.y);
  loads(0, 0, 0); run_ms(300);

  // ---- buttons / debounce ----
  pinval[4] = LOW; run_ms(6); CHECK((Joystick.buttons & 1) == 0, "no accept after one scan");
  run_ms(30); CHECK((Joystick.buttons & 1) == 1, "button 1 accepted");
  pinval[4] = HIGH; run_ms(40); CHECK((Joystick.buttons & 1) == 0, "button 1 released");

  // ---- overload: solid at 8 kg, latched flash at 12 kg ----
  g_load[1] = 8.2f; run_ms(100); CHECK(g_nearLimit && !g_overloadLatched, "warning at 8.2 kg");
  ledWrites = 0; int on = 0, tot = 0; for (int i = 0; i < 200; i++) { run_ms(2); tot++; on += pinval[17] == LOW; }
  CHECK(on == tot, "LED solid while warning (%d/%d)", on, tot);
  g_load[1] = 7.8f; run_ms(100); CHECK(g_nearLimit, "hysteresis holds at 7.8 kg");
  g_load[1] = 7.4f; run_ms(100); CHECK(!g_nearLimit, "warning clears below 7.5 kg");
  g_load[1] = 12.4f; run_ms(100); CHECK(g_overloadLatched, "latched at 12.4 kg");
  int toggles = 0, prev = pinval[17]; for (int i = 0; i < 1000; i++) { run_ms(1); if (pinval[17] != prev) { toggles++; prev = pinval[17]; } }
  CHECK(toggles >= 7 && toggles <= 9, "4 Hz flash => ~8 edges/s, got %d", toggles);
  g_load[1] = 0; run_ms(300); CHECK(g_overloadLatched, "latch survives load removal");
  CHECK(g_state == ST_RUN, "overload is not a FAULT");

  // ---- auto re-zero: slow drift is absorbed, overload offset check happens first ----
  g_off[2] += 60;  run_ms(2500);
  float before = g_tare[2]; run_ms(10000);
  CHECK(g_tare[2] - before > 5 && g_tare[2] - before < 15, "re-zero slew ~1 count/s, moved %.1f in 10 s", g_tare[2] - before);

  // ---- 't' command: tare to EEPROM ----
  g_off[0] += 900; keys("t"); run_ms(1200);
  CHECK(fabsf(g_tare[0] - (120000 + 900)) < 4, "manual tare %.1f", g_tare[0]);
  CHECK(has("saved to EEPROM"), "tare saved");
  CHECK(g_loadResult == LOAD_OK, "g_loadResult updated to LOAD_OK after manual tare");

  // ---- gesture: hold 5+6 for 2 s ----
  serial_out.clear(); pinval[8] = LOW; pinval[9] = LOW;
  for (int i = 0; i < 20; i++) {
    run_ms(2);
    CHECK((Joystick.buttons & 0x30) == 0, "buttons 5/6 must never leak into HID (got 0x%02X)", Joystick.buttons);
  }
  loads(0.5f, 0, 0); run_ms(2500);
  CHECK(!has("[TARE] done, saved"), "gesture must not fire while deflected under load");
  loads(0, 0, 0); run_ms(2800);
  CHECK(has("[TARE] done, saved"), "gesture re-tared once stick was centered");
  pinval[8] = HIGH; pinval[9] = HIGH; run_ms(200);

  // ---- guided calibration 'c' ----
  serial_out.clear(); keys("c\n"); run_ms(50);
  CHECK(has("Step 0"), "cal step 0 prompt");
  keys("\r\n"); run_ms(900); CHECK(has("Step 1"), "cal -> pitch step");
  loads(0.8f, 0, 0); run_ms(800); CHECK(Joystick.y == 0, "axes held neutral during cal"); keys("\n"); loads(0, 0, 0); run_ms(300);
  CHECK(has("Step 2"), "roll prompt (CRLF must not double-advance)");
  loads(0, 0.7f, 0); run_ms(800); keys("\n"); loads(0, 0, 0); run_ms(300);
  loads(0, 0, 0.45f / 3); run_ms(800); keys("\n"); loads(0, 0, 0); run_ms(300);
  CHECK(has("[CAL] saved"), "cal saved");
  CHECK(fabsf(g_cal.axisScale[0] - 128849) < 3000 && fabsf(g_cal.axisScale[1] - 1.5f * 0.7f * 107374) < 3000 && fabsf(g_cal.axisScale[2] - 0.45f * 107374) < 3000,
        "axis_scale %.0f %.0f %.0f", g_cal.axisScale[0], g_cal.axisScale[1], g_cal.axisScale[2]);
  loads(0.8f, 0, 0); run_ms(300); CHECK(Joystick.y < -32000, "calibrated full deflection y=%d", Joystick.y); loads(0, 0, 0); run_ms(300);
  // calibration rejection & roll reverse warning
  serial_out.clear(); keys("c\n"); run_ms(50); keys("\n"); run_ms(900);
  loads(0.8f, 0, 0); run_ms(800); keys("\n"); run_ms(50);
  loads(0, -0.7f, 0); run_ms(800); keys("\n"); run_ms(50);
  CHECK(has("NEGATIVE Roll"), "negative roll warning emitted");
  loads(0, 0, 0); keys("\n"); run_ms(50);
  CHECK(has("rejected") && has("nothing saved"), "empty extents rejected");
  saveEE("ee.bin");

  // ---- bench 'b' ----
  serial_out.clear(); keys("b\n"); run_ms(50); keys("\n"); run_ms(900);
  CHECK(has("unloaded baseline"), "bench baseline");
  for (int c = 0; c < 3; c++) { g_load[c] = 0.2f * (c == 1 ? 1.05f : 1.0f); keys("\n"); run_ms(900); g_load[c] = 0; }
  CHECK(has("cell 1: delta") && has("outside tolerance") == false, "bench ratios within 10%%");
  keys("y"); run_ms(50);
  CHECK(has("Span_i saved") && fabsf(g_cal.span[1] - 1.0f / 1.05f) < 0.01f, "span[1]=%.4f", g_cal.span[1]);
  g_cal.span[1] = 1.0f;
  keys("d"); run_ms(50); CHECK(has("state=RUN"), "dump works");

  // ---- NACK retry ----
  sim_nack_next = 2; run_ms(300); CHECK(g_state == ST_RUN, "transient NACKs are retried, state=%d", g_state);

  // ---- fault & recovery ----
  g_load[0] = 0.5f; run_ms(100);
  sim_dead[1] = true; run_ms(200); CHECK(g_state == ST_FAULT, "chip 0x41 gone -> FAULT");
  CHECK(Joystick.x == 0 && Joystick.y == 0 && Joystick.z == 0 && Joystick.buttons == 0, "FAULT centres axes");
  run_ms(6000); CHECK(g_state == ST_FAULT, "still FAULT while chip missing");
  g_load[0] = 0; sim_dead[1] = false; run_ms(8000); CHECK(g_state == ST_RUN, "recovered to RUN, state=%d", g_state);
  // stuck ADC
  g_noise = false; run_ms(1500); CHECK(g_state == ST_FAULT && has("stuck"), "stuck result detected");
  g_noise = true; run_ms(8000); CHECK(g_state == ST_RUN, "recovered after stuck");
  // pegged ADC at tare trips FAULT
  serial_out.clear();
  g_off[0] = 8388600; keys("t"); run_ms(600);
  CHECK(g_state == ST_FAULT && has("railed"), "pegged ADC at tare trips FAULT");
  g_off[0] = 120000; run_ms(8000); CHECK(g_state == ST_RUN, "recovered after pegged ADC cleared");

  printf("%d checks, %d failures\n", checks, fails);
  saveEE("ee.bin");
  return fails != 0;
}
