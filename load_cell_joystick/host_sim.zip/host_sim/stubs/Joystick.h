#pragma once
#include <Arduino.h>
#define JOYSTICK_DEFAULT_REPORT_ID 0x03
#define JOYSTICK_TYPE_JOYSTICK 0x04
struct Joystick_ {
  int16_t x = 0, y = 0, z = 0; uint8_t buttons = 0; uint32_t sends = 0; int btnCount;
  Joystick_(uint8_t, uint8_t, uint8_t bc, uint8_t, bool, bool, bool, bool, bool, bool, bool, bool, bool, bool, bool) { btnCount = bc; }
  void begin(bool = true) {}
  void setXAxisRange(int32_t, int32_t) {} void setYAxisRange(int32_t, int32_t) {} void setZAxisRange(int32_t, int32_t) {}
  void setXAxis(int32_t v) { x = v; } void setYAxis(int32_t v) { y = v; } void setZAxis(int32_t v) { z = v; }
  void setButton(uint8_t i, uint8_t v) { if (v) buttons |= (1 << i); else buttons &= ~(1 << i); }
  void sendState() { sends++; }
};
