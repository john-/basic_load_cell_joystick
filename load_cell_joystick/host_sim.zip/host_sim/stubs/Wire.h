#pragma once
#include <Arduino.h>
#define WIRE_HAS_TIMEOUT 1
// ---- fake ADS122C04 ----
extern int32_t sim_input(uint8_t addr, uint8_t mux);
struct FakeAds {
  uint8_t addr, reg[4] = {0, 0, 0, 0};
  bool converting = false, ready = false; uint64_t doneAt = 0; int32_t result = 0;
  uint8_t rdMode = 0, rdReg = 0; int starts = 0, resets = 0;
  int cfgErr = 0;
  void upd() { if (converting && sim_us >= doneAt) { converting = false; ready = true; } }
  bool drdyLow() { upd(); return ready; }
  void write(const uint8_t *b, int n) {
    int i = 0;
    while (i < n) {
      uint8_t c = b[i];
      if (c == 0x06) { reg[0] = reg[1] = reg[2] = reg[3] = 0; converting = ready = false; resets++; i++; }
      else if (c == 0x08) {
        bool cm = reg[1] & 0x08; uint8_t dr = reg[1] >> 5, mode = (reg[1] >> 4) & 1;
        if (cm) cfgErr++;                       // continuous mode would be a bug
        if (dr != 4 || mode != 0 || ((reg[1] >> 1) & 3) != 1 || ((reg[0] >> 1) & 7) != 7) cfgErr++;
        converting = true; ready = false; doneAt = sim_us + 3070 + 28; result = sim_input(addr, reg[0] >> 4); starts++; i++;
      }
      else if (c == 0x10) { rdMode = 1; i++; }
      else if ((c & 0xF3) == 0x20) { rdMode = 2; rdReg = (c >> 2) & 3; i++; }
      else if ((c & 0xF3) == 0x40) { reg[(c >> 2) & 3] = b[i + 1]; converting = ready = false; i += 2; }
      else i++;
    }
  }
  void read(uint8_t *o, int n) {
    upd();
    if (rdMode == 1) { uint32_t u = (uint32_t)result & 0xFFFFFF; o[0] = u >> 16; o[1] = u >> 8; o[2] = u; ready = false; }
    else if (rdMode == 2) { o[0] = reg[rdReg] | ((rdReg == 2 && ready) ? 0x80 : 0); }
    for (int i = 0; i < n; i++) if (rdMode == 0) o[i] = 0;
  }
};
extern FakeAds sim_ads[2];
extern int sim_nack_next;         // NACK this many upcoming transactions
extern bool sim_dead[2];          // device not answering
struct TwoWire {
  uint8_t tx[8], txn = 0, txaddr = 0, rx[8], rxn = 0, rxi = 0;
  void begin() {} void end() {}
  void setWireTimeout(uint32_t, bool) {}
  void beginTransmission(uint8_t a) { txaddr = a; txn = 0; }
  size_t write(uint8_t b) { tx[txn++] = b; return 1; }
  FakeAds *dev(uint8_t a) { for (int i = 0; i < 2; i++) if (sim_ads[i].addr == a && !sim_dead[i]) return &sim_ads[i]; return nullptr; }
  uint8_t endTransmission(uint8_t = 1) {
    sim_us += (txn + 1) * 45;
    FakeAds *d = dev(txaddr);
    if (!d) return 2;
    if (sim_nack_next > 0) { sim_nack_next--; return 3; }
    d->write(tx, txn); return 0;
  }
  uint8_t requestFrom(uint8_t a, uint8_t n) {
    sim_us += (n + 1) * 45; FakeAds *d = dev(a); rxi = 0; rxn = 0; if (!d) return 0;
    d->read(rx, n); rxn = n; return n;
  }
  int available() { return rxn - rxi; }
  int read() { return rxi < rxn ? rx[rxi++] : -1; }
};
extern TwoWire Wire;
