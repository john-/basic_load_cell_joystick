#pragma once
#include <stdint.h>
#include <stddef.h>
#include <string.h>
#include <math.h>
#include <stdio.h>
#include <string>
#define PROGMEM
class __FlashStringHelper;
#define F(x) (reinterpret_cast<const __FlashStringHelper *>(x))
#define HIGH 1
#define LOW 0
#define INPUT 0
#define OUTPUT 1
#define INPUT_PULLUP 2
#define DEC 10
#define HEX 16
extern uint64_t sim_us;
extern volatile uint8_t TWBR;
uint32_t millis(); uint32_t micros();
void delay(unsigned long ms); void delayMicroseconds(unsigned int us);
void pinMode(uint8_t, uint8_t); void digitalWrite(uint8_t, uint8_t); int digitalRead(uint8_t);
extern std::string serial_out;
extern std::string serial_in;
struct SerialStub {
  void begin(long) {}
  operator bool() const { return true; }
  int available() { return (int)serial_in.size(); }
  int read() { if (serial_in.empty()) return -1; int c = (unsigned char)serial_in[0]; serial_in.erase(0, 1); return c; }
  void out(const char *s) { serial_out += s; }
  size_t print(const char *s) { out(s); return 0; }
  size_t print(const __FlashStringHelper *s) { out((const char *)s); return 0; }
  size_t print(char c) { char b[2] = {c, 0}; out(b); return 1; }
  size_t print(unsigned char v, int base = DEC) { return print((unsigned long)v, base); }
  size_t print(int v, int base = DEC) { return print((long)v, base); }
  size_t print(unsigned int v, int base = DEC) { return print((unsigned long)v, base); }
  size_t print(long v, int base = DEC) { char b[40]; snprintf(b, 40, base == 16 ? "%lX" : "%ld", v); out(b); return 1; }
  size_t print(unsigned long v, int base = DEC) { char b[40]; snprintf(b, 40, base == 16 ? "%lX" : "%lu", v); out(b); return 1; }
  size_t print(double v, int d = 2) { char b[48]; snprintf(b, 48, "%.*f", d, v); out(b); return 1; }
  template <class T> size_t println(T v) { print(v); out("\n"); return 1; }
  template <class T> size_t println(T v, int b) { print(v, b); out("\n"); return 1; }
  size_t println() { out("\n"); return 1; }
};
extern SerialStub Serial;
