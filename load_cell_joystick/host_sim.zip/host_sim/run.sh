#!/bin/sh
# Host-side simulation of the sketch against a fake ADS122C04 pair (no hardware needed).
# Usage: sh run.sh [path/to/load_cell_joystick]   (default: ../load_cell_joystick)
set -e
HERE="$(cd "$(dirname "$0")" && pwd)"
SK="$(cd "${1:-$HERE/../load_cell_joystick}" && pwd)"
W="$(mktemp -d)"            # build/run in a temp dir (output folders may be mounted noexec)
g++ -std=gnu++11 -Wall -Wextra -Wno-unused-parameter -DF_CPU=8000000UL -DDEBUG_LEVEL=1 \
    -I"$HERE/stubs" -I"$SK" -x c++ "$HERE/sim_main.cpp" -o "$W/sim"
cd "$W"
./sim          # first boot (blank EEPROM) + full scenario, writes ee.bin
./sim reboot   # second boot: calibration must load from EEPROM
rm -rf "$W"
